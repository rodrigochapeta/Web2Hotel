/* tslint:disable */

export interface ReservaDto {
  fechaFin?: string;
  fechaInicio?: string;
  habitaciones?: number[];
  ususarioId?: number;
}
