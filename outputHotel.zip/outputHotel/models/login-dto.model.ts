/* tslint:disable */

export interface LoginDto {
  password?: string;
  username?: string;
}
