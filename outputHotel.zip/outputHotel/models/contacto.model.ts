/* tslint:disable */

export interface Contacto {
  apellido?: string;
  descripcion?: string;
  email?: string;
  estado?: string;
  id?: number;
  nombre?: string;
  telefono?: string;
}
